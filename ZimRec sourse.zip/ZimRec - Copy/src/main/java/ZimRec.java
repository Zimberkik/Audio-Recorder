import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ZimRec extends JFrame {

    private static final String FFMPEG = "C:\\ffmpeg\\bin\\ffmpeg.exe";

    // "Stereo Mix (Realtek High Definition Audio)"
    private static final String DEV_SYSTEM =
            "\u0421\u0442\u0435\u0440\u0435\u043E \u043C\u0438\u043A\u0448\u0435\u0440 (Realtek High Definition Audio)";

    // "Microphone (2- ENVONIX USB AUDIO)"
    private static final String DEV_MIC =
            "\u041C\u0438\u043A\u0440\u043E\u0444\u043E\u043D (2- ENVONIX USB AUDIO)";

    // Record gain: 2.0 = twice as loud. Lower to 1.5 if it distorts.
    private static final String GAIN = "2.0";

    private static final Color COL_ON       = new Color(46, 160, 67);
    private static final Color COL_OFF      = new Color(200, 40, 40);
    private static final Color COL_SEL      = new Color(70, 130, 220);
    private static final Color COL_BTN      = new Color(235, 235, 235);
    private static final Color COL_BTN_LINE = new Color(185, 185, 185);
    private static final Color COL_LINE     = new Color(150, 150, 150);

    private enum Action { SYSTEM, MIC, RECORD }

    private boolean systemOn = true;
    private boolean micOn = false;
    private String format = "mp3";
    private File folder;

    private JButton systemBtn;
    private JButton micBtn;
    private JButton recordBtn;
    private JLabel timerLabel;
    private JLabel folderLabel;
    private JButton[] formatButtons;

    private JLabel bindSystemLabel;
    private JLabel bindMicLabel;
    private JLabel bindRecordLabel;

    private Action capturing = null;
    private int keySystem = NativeKeyEvent.VC_F9;
    private int keyMic = NativeKeyEvent.VC_F10;
    private int keyRecord = NativeKeyEvent.VC_F8;
    private boolean hotkeysReady = false;

    private Process process;
    private javax.swing.Timer uiTimer;
    private long startMillis;
    private File currentFile;
    private final StringBuilder errBuf = new StringBuilder();

    public ZimRec() {
        super("Zim recorder");
        setAppIcon();

        folder = new File(System.getProperty("user.home"), "Music" + File.separator + "ZimRec");
        if (!folder.exists()) folder.mkdirs();

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setResizable(false);
        setSize(420, 660);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        ((JComponent) getContentPane()).setBorder(new FrameBorder());

        add(buildTitle(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (process != null) stopRecording();
                if (hotkeysReady) {
                    try {
                        GlobalScreen.unregisterNativeHook();
                    } catch (Exception ignored) {
                    }
                }
                dispose();
                System.exit(0);
            }
        });

        refreshToggles();
        refreshFormats();
        refreshFolder();

        initHotkeys();
        refreshBinds();
    }

    private void setAppIcon() {
        try {
            java.net.URL res = ZimRec.class.getResource("/icon.png");
            if (res != null) {
                setIconImage(new ImageIcon(res).getImage());
                return;
            }
            File f = new File("icon.png");
            if (f.exists()) {
                setIconImage(new ImageIcon(f.getAbsolutePath()).getImage());
                return;
            }
            File alt = new File("C:\\Users\\NAVI\\Documents\\Icons for minecraft \u2022\\rec.png");
            if (alt.exists()) {
                setIconImage(new ImageIcon(alt.getAbsolutePath()).getImage());
            }
        } catch (Exception ignored) {
        }
    }

    private void initHotkeys() {
        try {
            java.util.logging.Logger logger = java.util.logging.Logger.getLogger("com.github.kwhat.jnativehook");
            logger.setLevel(java.util.logging.Level.OFF);

            GlobalScreen.registerNativeHook();
            GlobalScreen.addNativeKeyListener(new NativeKeyListener() {
                @Override
                public void nativeKeyPressed(NativeKeyEvent e) {
                    int code = e.getKeyCode();

                    if (capturing != null) {
                        switch (capturing) {
                            case SYSTEM: keySystem = code; break;
                            case MIC:    keyMic = code;    break;
                            case RECORD: keyRecord = code; break;
                        }
                        capturing = null;
                        SwingUtilities.invokeLater(ZimRec.this::refreshBinds);
                        return;
                    }

                    if (code == keyRecord) {
                        SwingUtilities.invokeLater(ZimRec.this::toggleRecording);
                    } else if (code == keySystem) {
                        SwingUtilities.invokeLater(() -> {
                            if (process == null) {
                                systemOn = !systemOn;
                                refreshToggles();
                            }
                        });
                    } else if (code == keyMic) {
                        SwingUtilities.invokeLater(() -> {
                            if (process == null) {
                                micOn = !micOn;
                                refreshToggles();
                            }
                        });
                    }
                }

                @Override
                public void nativeKeyReleased(NativeKeyEvent e) {
                }

                @Override
                public void nativeKeyTyped(NativeKeyEvent e) {
                }
            });

            hotkeysReady = true;
        } catch (Throwable t) {
            hotkeysReady = false;
            System.out.println("Hotkeys disabled: " + t);
        }
    }

    private void refreshBinds() {
        if (bindSystemLabel != null) bindSystemLabel.setText("bind: " + NativeKeyEvent.getKeyText(keySystem));
        if (bindMicLabel != null) bindMicLabel.setText("bind: " + NativeKeyEvent.getKeyText(keyMic));
        if (bindRecordLabel != null) bindRecordLabel.setText("bind: " + NativeKeyEvent.getKeyText(keyRecord));
    }

    private void startCapture(Action a) {
        if (!hotkeysReady) {
            JOptionPane.showMessageDialog(this, "Hotkeys unavailable (jnativehook not loaded).",
                    "ZimRec", JOptionPane.WARNING_MESSAGE);
            return;
        }
        capturing = a;
        JLabel l = a == Action.SYSTEM ? bindSystemLabel : a == Action.MIC ? bindMicLabel : bindRecordLabel;
        if (l != null) l.setText("bind: press...");
    }

    private JLabel bindLabel(Action a) {
        JLabel l = new JLabel("bind: ...", SwingConstants.CENTER);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        l.setForeground(new Color(110, 110, 110));
        l.setCursor(new Cursor(Cursor.HAND_CURSOR));
        l.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                startCapture(a);
            }
        });
        return l;
    }

    private JComponent bindRow(JLabel label) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        p.add(label, BorderLayout.CENTER);
        return p;
    }

    private JComponent buildTitle() {
        JLabel t = new JLabel("Zim recorder", SwingConstants.CENTER);
        t.setFont(new Font("Segoe UI", Font.BOLD, 26));
        t.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, COL_LINE));
        p.add(t, BorderLayout.CENTER);
        return p;
    }

    private JComponent buildFooter() {
        JLabel f = new JLabel("MIT \u00A9 Zimberkik", SwingConstants.CENTER);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        f.setForeground(new Color(130, 130, 130));
        f.setBorder(BorderFactory.createEmptyBorder(4, 0, 8, 0));

        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.add(f, BorderLayout.CENTER);
        return p;
    }

    private void styleButton(JButton b) {
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setBorderPainted(true);
        b.setBorder(new LineBorder(COL_BTN_LINE, 1));
    }

    private JComponent buildBody() {
        JPanel root = new JPanel();
        root.setBackground(Color.WHITE);
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBorder(BorderFactory.createEmptyBorder(10, 10, 4, 10));

        // SYSTEM SOUND
        systemBtn = new JButton();
        systemBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        systemBtn.setPreferredSize(new Dimension(84, 34));
        styleButton(systemBtn);
        systemBtn.addActionListener(e -> {
            systemOn = !systemOn;
            refreshToggles();
        });

        bindSystemLabel = bindLabel(Action.SYSTEM);

        JPanel sysWrap = new JPanel(new BorderLayout());
        sysWrap.setBackground(Color.WHITE);
        sysWrap.add(sourceRow("SYSTEM SOUND", systemBtn), BorderLayout.CENTER);
        sysWrap.add(bindRow(bindSystemLabel), BorderLayout.SOUTH);
        root.add(section(sysWrap));
        root.add(Box.createVerticalStrut(8));

        // MICROPHONE
        micBtn = new JButton();
        micBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        micBtn.setPreferredSize(new Dimension(84, 34));
        styleButton(micBtn);
        micBtn.addActionListener(e -> {
            micOn = !micOn;
            refreshToggles();
        });

        bindMicLabel = bindLabel(Action.MIC);

        JPanel micWrap = new JPanel(new BorderLayout());
        micWrap.setBackground(Color.WHITE);
        micWrap.add(sourceRow("MICROPHONE", micBtn), BorderLayout.CENTER);
        micWrap.add(bindRow(bindMicLabel), BorderLayout.SOUTH);
        root.add(section(micWrap));
        root.add(Box.createVerticalStrut(8));

        // RECORD
        recordBtn = new JButton("Record");
        recordBtn.setFont(new Font("Segoe UI", Font.BOLD, 22));
        recordBtn.setBackground(COL_BTN);
        styleButton(recordBtn);
        recordBtn.addActionListener(e -> toggleRecording());

        timerLabel = new JLabel("00:00:00", SwingConstants.CENTER);
        timerLabel.setFont(new Font("Consolas", Font.PLAIN, 16));

        bindRecordLabel = bindLabel(Action.RECORD);

        JPanel recPanel = new JPanel();
        recPanel.setBackground(Color.WHITE);
        recPanel.setLayout(new BoxLayout(recPanel, BoxLayout.Y_AXIS));
        recPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 8, 10));
        recordBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        timerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        bindRecordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        recPanel.add(recordBtn);
        recPanel.add(Box.createVerticalStrut(6));
        recPanel.add(timerLabel);
        recPanel.add(Box.createVerticalStrut(4));
        recPanel.add(bindRecordLabel);
        root.add(section(recPanel));
        root.add(Box.createVerticalStrut(8));

        // AUDIO FORMAT
        JPanel fmtPanel = new JPanel();
        fmtPanel.setBackground(Color.WHITE);
        fmtPanel.setLayout(new BoxLayout(fmtPanel, BoxLayout.Y_AXIS));
        fmtPanel.setBorder(BorderFactory.createEmptyBorder(8, 10, 10, 10));

        JLabel fmtTitle = new JLabel("Audio format", SwingConstants.CENTER);
        fmtTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        fmtTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        fmtPanel.add(fmtTitle);
        fmtPanel.add(Box.createVerticalStrut(6));

        JPanel fmtRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        fmtRow.setBackground(Color.WHITE);

        String[] fmts = {"mp3", "ogg", "wav"};
        formatButtons = new JButton[fmts.length];
        for (int i = 0; i < fmts.length; i++) {
            final String f = fmts[i];
            JButton b = new JButton(f);
            b.setFont(new Font("Segoe UI", Font.BOLD, 14));
            Dimension d = new Dimension(84, 34);
            b.setPreferredSize(d);
            b.setMinimumSize(d);
            b.setMaximumSize(d);
            styleButton(b);
            b.addActionListener(e -> {
                if (process == null) {
                    format = f;
                    refreshFormats();
                }
            });
            formatButtons[i] = b;
            fmtRow.add(b);
        }
        fmtPanel.add(fmtRow);
        root.add(section(fmtPanel));
        root.add(Box.createVerticalStrut(8));

        // FOLDER
        JPanel folderPanel = new JPanel();
        folderPanel.setBackground(Color.WHITE);
        folderPanel.setLayout(new BoxLayout(folderPanel, BoxLayout.Y_AXIS));
        folderPanel.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

        JPanel folderRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        folderRow.setBackground(Color.WHITE);

        JButton folderBtn = new JButton("Folder");
        folderBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        folderBtn.setPreferredSize(new Dimension(100, 34));
        styleButton(folderBtn);
        folderBtn.addActionListener(e -> openFolder());

        JButton changeBtn = new JButton("Change");
        changeBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        changeBtn.setPreferredSize(new Dimension(100, 34));
        styleButton(changeBtn);
        changeBtn.addActionListener(e -> chooseFolder());

        folderRow.add(folderBtn);
        folderRow.add(changeBtn);

        folderLabel = new JLabel("", SwingConstants.CENTER);
        folderLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        folderLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        folderPanel.add(folderRow);
        folderPanel.add(Box.createVerticalStrut(4));
        folderPanel.add(folderLabel);
        root.add(section(folderPanel));

        return root;
    }

    private static class SectionPanel extends JPanel {
        SectionPanel(LayoutManager lm) {
            super(lm);
            setBackground(Color.WHITE);
        }

        @Override
        public Dimension getMaximumSize() {
            return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
        }
    }

    private static class FrameBorder extends javax.swing.border.AbstractBorder {
        private static final int W = 4;

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(W, W, W, W);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.set(W, W, W, W);
            return insets;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();

            Color outer = new Color(245, 245, 245);
            Color inner = new Color(55, 55, 55);

            g2.setPaint(new GradientPaint(x, y, outer, x, y + W, inner));
            g2.fillRect(x, y, w, W);

            g2.setPaint(new GradientPaint(x, y, outer, x + W, y, inner));
            g2.fillRect(x, y, W, h);

            g2.setPaint(new GradientPaint(x + w, y, outer, x + w - W, y, inner));
            g2.fillRect(x + w - W, y, W, h);

            g2.setPaint(new GradientPaint(x, y + h, outer, x, y + h - W, inner));
            g2.fillRect(x, y + h - W, w, W);

            g2.dispose();
        }
    }

    private JComponent section(JComponent inner) {
        SectionPanel p = new SectionPanel(new BorderLayout());
        p.setBorder(new LineBorder(COL_LINE, 2));
        p.add(inner, BorderLayout.CENTER);
        return p;
    }

    private JComponent sourceRow(String title, JComponent right) {
        JPanel p = new JPanel(new BorderLayout(10, 0));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 6, 10));

        JLabel l = new JLabel(title);
        l.setFont(new Font("Segoe UI", Font.BOLD, 18));

        p.add(l, BorderLayout.CENTER);
        p.add(right, BorderLayout.EAST);
        return p;
    }

    private void refreshToggles() {
        styleToggle(systemBtn, systemOn);
        styleToggle(micBtn, micOn);
    }

    private void styleToggle(JButton b, boolean on) {
        b.setText(on ? "ON" : "OFF");
        b.setBackground(on ? COL_ON : COL_OFF);
        b.setForeground(Color.WHITE);
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setBorderPainted(true);
        b.setBorder(new LineBorder(COL_BTN_LINE, 1));
    }

    private void refreshFormats() {
        String[] fmts = {"mp3", "ogg", "wav"};
        for (int i = 0; i < formatButtons.length; i++) {
            boolean sel = fmts[i].equals(format);
            JButton b = formatButtons[i];
            b.setBackground(sel ? COL_SEL : COL_BTN);
            b.setForeground(sel ? Color.WHITE : Color.BLACK);
            b.setOpaque(true);
            b.setContentAreaFilled(true);
            b.setBorderPainted(true);
            b.setBorder(new LineBorder(COL_BTN_LINE, 1));
        }
    }

    private void refreshFolder() {
        folderLabel.setText(folder.getAbsolutePath());
    }

    private File nextFile() {
        int max = 0;
        File[] files = folder.listFiles();
        if (files != null) {
            for (File f : files) {
                String n = f.getName();
                if (!n.startsWith("record ")) continue;
                String rest = n.substring(7);
                int dot = rest.indexOf('.');
                if (dot >= 0) rest = rest.substring(0, dot);
                try {
                    int v = Integer.parseInt(rest.trim());
                    if (v > max) max = v;
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return new File(folder, "record " + (max + 1) + "." + format);
    }

    private void openFolder() {
        try {
            if (!folder.exists()) folder.mkdirs();
            Desktop.getDesktop().open(folder);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Cannot open folder:\n" + ex.getMessage(),
                    "ZimRec", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void chooseFolder() {
        JFileChooser fc = new JFileChooser(folder);
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fc.setDialogTitle("Choose folder for recordings");
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            folder = fc.getSelectedFile();
            refreshFolder();
        }
    }

    private void toggleRecording() {
        if (process == null) startRecording();
        else stopRecording();
    }

    private void startRecording() {
        if (!systemOn && !micOn) {
            JOptionPane.showMessageDialog(this, "Select at least one audio source.",
                    "ZimRec", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!new File(FFMPEG).exists()) {
            JOptionPane.showMessageDialog(this, "ffmpeg not found:\n" + FFMPEG,
                    "ZimRec", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!folder.exists()) folder.mkdirs();

        currentFile = nextFile();

        List<String> cmd = buildCommand(currentFile);
        errBuf.setLength(0);

        try {
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(false);
            process = pb.start();

            final Process p = process;
            Thread reader = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(p.getErrorStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        errBuf.append(line).append('\n');
                    }
                } catch (IOException ignored) {
                }
            });
            reader.setDaemon(true);
            reader.start();

            startMillis = System.currentTimeMillis();
            timerLabel.setText("00:00:00");

            recordBtn.setText("Recording...");
            recordBtn.setBackground(COL_OFF);
            recordBtn.setForeground(Color.WHITE);
            recordBtn.setOpaque(true);

            systemBtn.setEnabled(false);
            micBtn.setEnabled(false);
            for (JButton b : formatButtons) b.setEnabled(false);

            uiTimer = new javax.swing.Timer(200, e -> updateTimer());
            uiTimer.start();

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to start ffmpeg:\n" + ex.getMessage(),
                    "ZimRec", JOptionPane.ERROR_MESSAGE);
        }
    }

    private List<String> buildCommand(File out) {
        List<String> c = new ArrayList<>();
        c.add(FFMPEG);
        c.add("-hide_banner");
        c.add("-loglevel");
        c.add("error");
        c.add("-y");

        int inputs = 0;
        if (systemOn) {
            c.add("-f");
            c.add("dshow");
            c.add("-i");
            c.add("audio=" + DEV_SYSTEM);
            inputs++;
        }
        if (micOn) {
            c.add("-f");
            c.add("dshow");
            c.add("-i");
            c.add("audio=" + DEV_MIC);
            inputs++;
        }

        String gain = "volume=" + GAIN;

        if (inputs == 2) {
            c.add("-filter_complex");
            c.add("[0:a][1:a]amix=inputs=2:duration=longest:dropout_transition=0," + gain + "[a]");
            c.add("-map");
            c.add("[a]");
        } else {
            c.add("-af");
            c.add(gain);
        }

        if ("mp3".equals(format)) {
            c.add("-c:a");
            c.add("libmp3lame");
            c.add("-b:a");
            c.add("192k");
        } else if ("ogg".equals(format)) {
            c.add("-c:a");
            c.add("libvorbis");
            c.add("-q:a");
            c.add("5");
        } else {
            c.add("-c:a");
            c.add("pcm_s16le");
        }

        c.add(out.getAbsolutePath());
        return c;
    }

    private void updateTimer() {
        long ms = System.currentTimeMillis() - startMillis;
        timerLabel.setText(formatTime(ms));

        if (process != null && !process.isAlive()) {
            process = null;
            finishUi();
            String err = errBuf.toString().trim();
            if (err.isEmpty()) err = "ffmpeg stopped unexpectedly.";
            JOptionPane.showMessageDialog(this, err, "ZimRec", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String formatTime(long ms) {
        long s = ms / 1000;
        return String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60);
    }

    private void stopRecording() {
        Process p = process;
        if (p == null) return;

        try {
            OutputStream os = p.getOutputStream();
            os.write("q\n".getBytes(StandardCharsets.US_ASCII));
            os.flush();
            os.close();
        } catch (IOException ignored) {
        }

        try {
            if (!p.waitFor(6, TimeUnit.SECONDS)) p.destroyForcibly();
        } catch (InterruptedException e) {
            p.destroyForcibly();
        }

        process = null;
        finishUi();

        String err = errBuf.toString().trim();
        boolean ok = currentFile != null && currentFile.exists() && currentFile.length() > 0;

        if (!ok) {
            JOptionPane.showMessageDialog(this,
                    "Recording failed.\n\n" + (err.isEmpty() ? "No output file was created." : err),
                    "ZimRec", JOptionPane.ERROR_MESSAGE);
        } else if (!err.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Saved:\n" + currentFile.getAbsolutePath() + "\n\nffmpeg:\n" + err,
                    "ZimRec", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void finishUi() {
        if (uiTimer != null) {
            uiTimer.stop();
            uiTimer = null;
        }

        timerLabel.setText("00:00:00");

        recordBtn.setText("Record");
        recordBtn.setBackground(COL_BTN);
        recordBtn.setForeground(Color.BLACK);
        recordBtn.setOpaque(true);

        systemBtn.setEnabled(true);
        micBtn.setEnabled(true);
        for (JButton b : formatButtons) b.setEnabled(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ZimRec().setVisible(true));
    }
}
