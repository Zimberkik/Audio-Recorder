@echo off
cd /d "%~dp0"
java -cp "ZimRec.jar;jnativehook-2.2.2.jar" ZimRec
pause
